# all-in-one

This folder is an all-in-one setup package for our ethereum mining rigs on ubuntu