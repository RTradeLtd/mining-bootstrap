#! /bin/bash

# make boot scripts directory
sudo mkdir /boot_scripts
# change ownership
sudo chown -R rtrade:rtrade /boot_scripts
# copy ethmienr binary
sudo cp ethminer /usr/local/bin
# copy ethminer start script
cp ethminer_start.sh /boot_scripts
# copy miner systemd service
sudo cp miner.service /etc/systemd/systemd
# enable miner service, after installing the nvidia drivers the system will automatically reboot
# enabling the miner service ensures that after the reboot we begin mining immediately
sudo systemctl enable miner.service
# install nvidia
bash nvidia_install.sh